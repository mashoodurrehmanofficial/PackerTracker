data = [{'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '12'}, {'barcode': 'SRig1', 'total_jumps': '16'}, {'barcode': 'SRig4', 'total_jumps': '16'}, {'barcode': 'Srig5', 'total_jumps': '12'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '14'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '0'}, {'barcode': 'SRig1', 'total_jumps': '0'}, {'barcode': 'SRig4', 'total_jumps': '0'}, {'barcode': 'Srig5', 'total_jumps': '0'}, {'barcode': 'SRig14', 'total_jumps': 
'0'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, 
{'barcode': 'SRig13', 'total_jumps': '14'}, {'barcode': 'SRig10', 'total_jumps': '0'}, {'barcode': 'SRig1', 'total_jumps': '0'}, {'barcode': 'SRig4', 'total_jumps': '0'}, {'barcode': 'Srig5', 'total_jumps': '0'}, {'barcode': 'SRig14', 'total_jumps': '0'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig10', 'total_jumps': '0'}, {'barcode': 'SRig1', 'total_jumps': '0'}, {'barcode': 'SRig4', 'total_jumps': '0'}, {'barcode': 'Srig5', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '0'}, {'barcode': 'SRig1', 'total_jumps': '0'}, {'barcode': 'SRig4', 'total_jumps': '0'}, {'barcode': 'Srig5', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '0'}, {'barcode': 'SRig1', 'total_jumps': '0'}, {'barcode': 'SRig4', 'total_jumps': '0'}, {'barcode': 'Srig5', 'total_jumps': '0'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '14'}, {'barcode': 'SRig10', 'total_jumps': '0'}, {'barcode': 'SRig1', 'total_jumps': '0'}, {'barcode': 'SRig4', 'total_jumps': '0'}, {'barcode': 'Srig5', 'total_jumps': '0'}, {'barcode': 'SRig14', 'total_jumps': '0'}, {'barcode': 'SRig13', 'total_jumps': '0'}, {'barcode': 'SRig10', 'total_jumps': '3'}, {'barcode': 'SRig1', 'total_jumps': '4'}, {'barcode': 'SRig4', 'total_jumps': '4'}, {'barcode': 'Srig5', 'total_jumps': '3'}, {'barcode': 'SRig14', 'total_jumps': '16'}, {'barcode': 'SRig13', 'total_jumps': '14'}]



import re
# container  = {}
# for rig in data:
#     if rig['barcode'] in list(container.keys()):  container[rig['barcode']] =  int(container[rig['barcode']] ) +  int(rig['total_jumps'] )  # add + 
#     else:   container[rig['barcode']] = int(rig['total_jumps'] )
        
# # pip install natsort==3.3.0

 
# from natsort import natsorted

# labels = natsorted(list(container.keys()))
# data_set = [container[x] for x in labels]
# print (labels)
# print (data_set)
# kevin890023958793
# kevin890023958793#$*/


data = [[['S-RIG-01'], ['5'], ['2009', ''], ['209'], ['209'], ['2009', ''], ['19'], ['400'], ['s'], ['1']], [['S-RIG-02'], ['3'], ['116'], ['116'], ['116'], ['116'], ['116'], ['350'], ['s'], ['2']], [['S-RIG-03'], ['5'], ['1007', ''], ['107'], ['107'], ['1007', ''], ['207'], ['350'], ['s'], ['3']], [['S-RIG-04'], ['5'], ['1016', ''], ['216'], ['216'], ['1016', ''], ['16'], ['350'], ['s'], ['4']], [['S-RIG-05'], ['11'], ['515', ''], ['265'], ['765', ''], ['515', ''], ['515', ''], ['450'], ['s'], ['5']], [['S-RIG-06'], ['3'], ['254'], ['254'], ['754', ''], ['254'], ['254'], ['450'], ['s'], ['6']], [['S-RIG-07'], ['10'], ['1515', ''], ['315'], ['815', ''], ['1515', ''], ['515', ''], ['350'], ['s'], ['7']], [['S-RIG-08'], ['4'], ['260'], ['60'], ['60'], ['260'], ['260'], ['350'], ['s'], ['8']], [['S-RIG-09'], ['7'], ['863', ''], ['363', ''], ['863', ''], ['763', ''], ['213'], ['350'], ['s'], ['9']], [['S-RIG-10'], ['1'], ['1010', ''], ['2'], ['2'], ['1010', ''], ['260'], ['350'], ['s'], ['10']], [['S-RIG-11'], ['7'], ['1010', ''], 
['410', ''], ['910', ''], ['1010', ''], ['35'], ['350'], ['s'], ['11']], [['S-RIG-12'], ['3'], ['508', ''], ['253'], ['753', ''], ['603', ''], ['603', ''], ['350'], ['s'], ['12']], [['S-RIG-13'], ['1'], ['1252', ''], ['4'], ['1004', ''], ['1252', ''], ['502', ''], ['350'], ['s'], ['13']], [['S-RIG-14'], ['1'], ['601', ''], ['256'], ['756', ''], ['506', ''], ['506', ''], ['350'], ['s'], ['14']], [['S-RIG-15'], ['7'], ['1019', ''], ['219'], ['1219', ''], ['1019', ''], ['119'], ['350'], ['s'], ['15']], [['S-RIG-16'], ['4'], ['759', ''], ['384', ''], ['1384', ''], ['759', ''], ['59'], ['350'], ['s'], ['16']], [['S-RIG-17'], ['15'], ['767', ''], ['267'], ['767', ''], ['767', ''], ['67'], ['350'], ['s'], ['17']], [['S-RIG-18'], ['7'], ['109'], ['109'], ['609', ''], ['109'], ['109'], ['450'], ['s'], ['18']], [['S-RIG-19'], ['11'], ['115'], ['35'], ['1035', ''], ['115'], ['115'], ['350'], ['s'], ['19']], [['S-RIG-20'], ['4'], ['24'], ['354', ''], ['354', ''], ['24'], ['24'], ['350'], ['s'], ['20']], [['T-RIG-01'], ['3'], ['3'], 
['3'], ['3'], ['3'], ['3'], ['200'], ['t'], ['1']], [['T-RIG-02'], ['3'], ['3'], ['3'], ['3'], ['3'], ['3'], ['200'], ['t'], ['2']], [['T-RIG-03'], 
['3'], ['2003', ''], ['253', ''], ['1753', ''], ['2003', ''], ['23'], ['200'], ['t'], ['3']], [['T-RIG-04'], ['3'], ['2003', ''], ['253'], ['1253', 
''], ['2003', ''], ['103'], ['450'], ['t'], ['4']], [['T-RIG-05'], ['3'], ['2003', ''], ['53'], ['53'], ['2003', ''], ['403', ''], ['200'], ['t'], ['5']], [['T-RIG-06'], ['3'], ['1503', ''], ['13'], ['13'], ['1503', ''], ['403', ''], ['200'], ['t'], ['6']], [['T-RIG-07'], ['4'], ['1504', ''], ['254', ''], ['1254', ''], ['1504', ''], ['254', ''], ['200'], ['t'], ['7']], [['T-RIG-08'], ['4'], ['2012', ''], ['32'], ['1032', ''], ['2012', ''], 
['812', ''], ['400'], ['t'], ['8']], [['T-RIG-09'], ['3'], ['310', ''], ['260', ''], ['860', ''], ['310', ''], ['310', ''], ['200'], ['t'], ['9']], 
[['T-RIG-10'], ['4'], ['1505', ''], ['305', ''], ['805', ''], ['1505', ''], ['805', ''], ['200'], ['t'], ['10']]]


def sorted_nicely( l ): 
    """ Sort the given iterable in the way that humans expect.""" 
    convert = lambda text: int(text) if text.isdigit() else text 
    alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
    return sorted(l, key = alphanum_key)

s = set(['booklet', '4 sheets', '48 sheets', '12 sheets'])
s = [x[0][0] for x in data]
for x in sorted_nicely(s):
    print(x)